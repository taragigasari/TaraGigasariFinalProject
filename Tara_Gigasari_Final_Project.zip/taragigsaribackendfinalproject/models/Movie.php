<?php
    class Movie {
        // DB Stuff
        private $conn;
        private $table = 'movie';

        // Movie Properties
        public $searchquery;
        public $id;
        public $title;
        public $description;
        public $year;
        public $poster;

        // Constructor
        public function __construct($db)
        {
            $this->conn = $db;
        }

        // Get Movies
        public function read() {
            // create query
            $query = 'SELECT * from ' . $this->table . ';';
            $stmt = $this->conn->prepare($query);

            // Execute query
            $stmt->execute();

            return $stmt;
        }

        // Create Movie
        public function create() {
            // create query
            $query = 'insert into ' . $this->table . ' (title,description,year,poster) values(:title,:description,:year,:poster);';

            // Prepare statement
            $stmt = $this->conn->prepare($query);

            // Format Data
            $this->title = htmlspecialchars(strip_tags($this->title));
            $this->description = htmlspecialchars(strip_tags($this->description));
            $this->year = htmlspecialchars(strip_tags($this->year));
            $this->poster = htmlspecialchars(strip_tags($this->poster));

            // Bind the data
            $stmt->bindParam(':title', $this->title);
            $stmt->bindParam(':description', $this->description);
            $stmt->bindParam(':year', $this->year);
            $stmt->bindParam(':poster', $this->poster);

            // Execute query
            return $stmt->execute();
        }

        // Search Movies
        public function search() {
            // create query
            $query = 'select * from ' . $this->table . ' where title=:title or year=:year';

            // Prepare statement
            $statement = $this->conn->prepare($query);

            // Bind the data
            if (isset($this->searchquery)) {
                $statement->bindParam(':title', $this->searchquery);
                $statement->bindParam(':year', $this->searchquery);
            } else {
                $query = 'select * from ' . $this->table;
            }

            // Execute query
            $statement->execute();

            return $statement;
        }

        // Delete Movies
        public function delete() {
            // create query
            $query = 'delete from ' . $this->table . ' where id=:id';

            // compile statement
            $statement = $this->conn->prepare($query);

            // Bind the data
            $statement->bindParam(':id', $this->id);

            // Execute query
            $statement->execute();

            return $statement;
        }

        // Edit Movie
        public function edit() {
            // create query
            $query = 'update ' . $this->table . ' set title=:title, description=:description, year=:year, poster=:poster where id=:id;';

            // Prepare statement
            $stmt = $this->conn->prepare($query);

            // Reformat Data
            $this->id = htmlspecialchars(strip_tags($this->id));
            $this->title = htmlspecialchars(strip_tags($this->title));
            $this->description = htmlspecialchars(strip_tags($this->description));
            $this->year = htmlspecialchars(strip_tags($this->year));
            $this->poster = htmlspecialchars(strip_tags($this->poster));

            // Bind the data
            $stmt->bindParam(':id', $this->id);
            $stmt->bindParam(':title', $this->title);
            $stmt->bindParam(':description', $this->description);
            $stmt->bindParam(':year', $this->year);
            $stmt->bindParam(':poster', $this->poster);

            // Execute query
            try {
                $stmt->execute();
                return true;
            } catch (Exception $e) {
                printf("Error: %s.\n", $stmt->error);
                return false;
            }
        }

    }