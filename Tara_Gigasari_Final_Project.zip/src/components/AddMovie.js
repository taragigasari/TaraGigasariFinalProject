
import { useState } from "react";
import { Form, Button } from 'react-bootstrap'; 
import axios from "axios";


export default function AddMovie(){
  const [name, setName] = useState();
    const [year, setYear] = useState();
    const [description, setDescription] = useState();
    const [poster, setPoster] = useState();

    const handleName = (event) => {
      setName(event.target.value);
  }
  const handleYear = (event) => {
      setYear(event.target.value);
  }
  const handleDescription = (event) => {
      setDescription(event.target.value);
  }
  const handlePoster = (event) => {
      setPoster(event.target.value);
  }
  const handleClick=() => {
    axios.post("http://localhost:8000/api/movie/create.php",{form: { name:name,year:year,description:description,poster:poster }})
    .then(function(response){
      console.log(response);
    });
  }
  ;
    return(
    
      <div>
  <Form.Group className="form mb-0 p-4  col-xs-2"  controlId="formBasicName" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Name:</Form.Label>
    <Form.Control type="name" placeholder="Movie Name" onChange={handleName} />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicYear" >
    <Form.Label className="p-3 mb-2 bg-dark text-white"> Released Year:</Form.Label>
    <Form.Control type="year" placeholder="year" onChange={handleYear} />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicDescription" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Description:</Form.Label>
    <Form.Control as="textarea" placeholder="description" rows={3}  onchange={handleDescription}/>
  </Form.Group>
  <Form.Group  className="form mb-0 p-4  col-xs-2" controlId="formBasicPoster" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Poster:</Form.Label>
    <Form.Control as="textarea" placeholder="poster" rows={3} onchange={handlePoster} />
  </Form.Group>
  <div className="d-flex h-100">
  <div className="align-self-center mx-auto">
  <Button className="btn btn-primary" variant="secondary" onClick={handleClick}>
    Submit
  </Button>
  </div>
  </div>
            
</div>
     
                

    ) 
}
