import { useState } from "react";

import axios from "axios";
import { Form, Button ,Navbar, Nav,NavLink} from 'react-bootstrap'
import { Container } from "@mui/material";
import Home from "./Home";
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: "70%",
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

export default function Header() {
    const [name, setName] = useState();
    const [year, setYear] = useState();
    const [description, setDescription] = useState();
    const [poster, setPoster] = useState();

    const handleName = (event) => {
      setName(event.target.value);
  }
  const handleYear = (event) => {
      setYear(event.target.value);
  }
  const handleDescription = (event) => {
      setDescription(event.target.value);
  }
  const handlePoster = (event) => {
      setPoster(event.target.value);
  }
  const handleClick = () => {
    axios.post("http://localhost:8000/api/movie/create.php",{title:name,year:year,description:description,poster:poster})
    .then(function(response){});
    window.location.reload();
  }

  const handleView = (viewMode) => {
    console.log(viewMode);
    localStorage.setItem('viewMode', viewMode);
    window.location.reload();
  }

    const [isRun, setRun] = useState(true);
    const gridView = () => {
        if (!isRun)
        setRun(true);
    };

    const listView = () =>{
        if(isRun)
        setRun(false);
    };
    const[addPage,setAddPage] = useState(false);
    const handleAddPage =
    () => {
        setAddPage(!addPage)
    }

return(
    <>

    <Navbar bg="dark" variant="dark">
    <Container>
      <Navbar.Brand  title={"movies"} className="ms-3"href="#home">
      </Navbar.Brand>
      <Nav className="me-auto">
            <NavLink className="link">HOME</NavLink>
            <NavLink onClick={handleAddPage} className="link">ADD</NavLink>
            <NavLink onClick={() => handleView('grid')} className="link" >GRID VIEW</NavLink>
            <NavLink onClick={() => handleView('list')} className="link" >LIST VIEW</NavLink>
            
        </Nav>
    </Container>
  </Navbar>
   
 <Home view={isRun}></Home>

 <Modal
        open={addPage}
        onClose={handleAddPage}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
        <Form>
  <Form.Group className="formmb-0 p-4  col-xs-2"  controlId="formBasicName" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Name:</Form.Label>
    <Form.Control name="title" onChange={handleName} placeholder="Movie Name"  />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicYear" >
    <Form.Label className="p-3 mb-2 bg-dark text-white"> Released Year:</Form.Label>
    <Form.Control name="year" onChange={handleYear} placeholder="year" type="number"  />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicDescription" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Description:</Form.Label>
    <Form.Control as="textarea" name="description" onChange={handleDescription} placeholder="description" rows={3}  />
  </Form.Group>
  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicPoster" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Poster:</Form.Label>
    <Form.Control name="poster" as="textarea" onChange={handlePoster} placeholder="poster" rows={3}/>
  </Form.Group>
  <div className="d-flex h-100">
  <div className="align-self-center mx-auto">
  <Button className="btn btn-primary" variant="secondary" onClick={handleClick}>
    Add Movie
  </Button>
  </div>
  </div>
            
</Form>

        </Box>
      </Modal>

 </>
  
);

}