import axios from "axios";
import { useEffect, useState } from "react";
import './GridView.css';
import './ListView.css';
import { Button,FormControl,Form } from "react-bootstrap";
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: "70%",
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const Card=({view,movie}) =>
{
    var convert = view?"gridView":"listView";
    const[newMovie,setNewMovie]= useState(movie);
    const[letOpen,setLetOpen]= useState(false);
    function handleOpen(){
      setLetOpen(!letOpen);
    }
    function handleNewMovie(event){
      setNewMovie({...newMovie,[event.target.name]:event.target.value})
    }
async function handleUpdate(){
  await axios.post(
    "http://localhost:8000/api/movie/update.php",
    newMovie);
   window.location.reload();
}
async function handleDelete(){
  try {
    await axios.post(
      "http://localhost:8000/api/movie/delete.php?id="+movie.id,
      newMovie);
  } catch (error) {
    console.error(error);
  }
   window.location.reload();
}
    return(
      <>
      <Modal
        open={letOpen}
        onClose={handleOpen}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
        <Form style={{backgroundImage:`url(${movie.poster})`,backgroundPosition:"center",backgroundRepeat:"no-repeat" ,backgroundSize:"cover"}}>
  <Form.Group  className="form mb-0 p-4  col-xs-2"  controlId="formBasicName" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Name:</Form.Label>
    <Form.Control type="text" defaultValue={movie.title} name="title" onChange={handleNewMovie} placeholder="Movie Name" />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicYear" >
    <Form.Label className="p-3 mb-2 bg-dark text-white"> Released Year:</Form.Label>
    <Form.Control defaultValue={movie.year} type="number" name="year" onChange={handleNewMovie} placeholder="year"  />
  </Form.Group>

  <Form.Group className="form mb-0 p-4  col-xs-2" controlId="formBasicDescription" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Description:</Form.Label>
    <Form.Control defaultValue={movie.description} name="description" as="textarea" onChange={handleNewMovie} placeholder="description" rows={3}  />
  </Form.Group>
  <Form.Group   className="form mb-0 p-4  col-xs-2" controlId="formBasicPoster" >
    <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Poster:</Form.Label>
    <Form.Control defaultValue={movie.poster} as="textarea" name="poster" onChange={handleNewMovie} placeholder="poster" rows={3}/>
  </Form.Group>
      <div className="d-flex flex-row justify-content-center">
      <div className="d-flex h-100 mx-2 my-3">
  <div className="align-self-center mx-auto">
  <Button className="btn btn-primary" variant="secondary" onClick={handleDelete}>
    Delete
  </Button>
  </div>
  </div>
  <div className="d-flex h-100 mx-2 my-3">
  <div className="align-self-center mx-auto">
  <Button className="btn btn-primary" variant="secondary" onClick={handleUpdate}>
    Edit
  </Button>
  </div>
  </div>
      </div>
            
</Form>
        </Box>
      </Modal>
      <div onClick={handleOpen} style={{ display: 'flex', flexDirection: 'col', flexWrap: 'wrap', borderRadius: '1rem' ,backgroundImage: `url(${movie.poster})`, justifyContent: 'center', backgroundSize: 'poster', backgroundPosition: 'center', cursor: 'pointer'  }} className={`m-2 ${convert}`}>
          <h3 className="title" style={{ minWidth: '75%', textAlign: 'center', backgroundColor: 'rgba(255, 255, 255, 0.5)', borderRadius: '1rem', marginTop: '22rem' }}>
            {movie.title}
            <span>
              {` - ${movie.year}`}
            </span>
          </h3>
        </div>
        </>
    )
}

export default function Home({view}){
    const [home,setHome]= useState();
    const [hasGot, setGot] = useState(false);
    const load= async()=>{
      if (!hasGot) {
        const total = await axios.get("http://localhost:8000/api/movie/read.php")
        setHome(total.data.data);
        setGot(true);
      }
    }
    const[find,setFind]= useState();
    const handleFind = async()=> {const findRes=await axios.get(`http://localhost:8000/api/movie/search.php?searchquery=${find}`);
  setHome(findRes.data.data);
  };

    useEffect(() => {
        if (!home) load();
      }, [home]);
    return(
        <div className="container">
        <Form className="d-flex my-4" style={{ height: "50px" }}>
          <FormControl
            type="find"
            placeholder="Find movie by name/year"
            className="me-2"
            aria-label="Find"
            onChange={(e) => {
              setFind(e.target.value);
            }}
          />
          <Button variant="outline-dark" onClick={handleFind}>
            Search
          </Button>
        </Form>
            <div className={`d-flex flex-${localStorage.getItem('viewMode') === 'grid' ? 'row' : 'column'} justify-content-between`} style={{ flexWrap: 'wrap' }}>
              {home && home.length > 0 ? home.map((mov, key)=>{return( <Card key={key} view={view} movie={mov}></Card>);}) : 'No Movie Found!'}
            </div>
        </div>
    );
}