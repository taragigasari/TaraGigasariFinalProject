import React from 'react';
import { Form, Button } from 'react-bootstrap';
export default function EditMovie(){
    return(
    
        <Form>
    <Form.Group className="form"  className="mb-0 p-4  col-xs-2"  controlId="formBasicName">
      <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Name:</Form.Label>
      <Form.Control type="name" placeholder="Movie Name" />
    </Form.Group>
  
    <Form.Group className="form" className="mb-0 p-4  col-xs-2" controlId="formBasicYear">
      <Form.Label className="p-3 mb-2 bg-dark text-white"> Released Year:</Form.Label>
      <Form.Control type="year" placeholder="year" />
    </Form.Group>
  
    <Form.Group className="form"  className="mb-0 p-4  col-xs-2" controlId="formBasicDescription">
      <Form.Label className="p-3 mb-2 bg-dark text-white">Description:</Form.Label>
      {/* <Form.Control type="description" placeholder="description" /> */}
      <Form.Control as="textarea" placeholder="description" rows={3} />
    </Form.Group>
    <Form.Group className="form"  className="mb-0 p-4  col-xs-2" controlId="formBasicPoster">
      <Form.Label className="p-3 mb-2 bg-dark text-white">Movie Poster:</Form.Label>
      {/* <Form.Control type="poster" placeholder="poster" /> */}
      <Form.Control as="textarea" placeholder="poster" rows={3} />
    </Form.Group>
    <div className="d-flex h-100">
    <div className="align-self-center mx-auto">
    <Button className="btn btn-primary" variant="secondary" type="update">
      Update movie info
    </Button>
    </div>
    </div>
              
  </Form>
       
                  
  
      ) 
}